
function [X] = TWPMFGS(Omsi,sr,opt)

    tol   = opt.tol;
    maxit = opt.maxit;
    
    Nway = size(Omsi);
    rand('seed',2);
    Omega = find(rand(prod(Nway),1)<sr);
    Y_init = initialization_M(Nway, Omega, Omsi(Omega));
    Ndim = ndims(Y_init); 

    [row, col, channel] = size(Omsi);
    tsize=[row, col, channel];

%     %% Miss_Data
%     Observe = zeros(Nway);
%     Observe(Omega) = T(Omega);
%     Xtrue = T;
    
    lamda = opt.lamda;
    mu = opt.mu;
    ri =  opt.r; 
    r = [ri, ri, ri];
    
    Ri = opt.Ri;
    Li = opt.Li;  
    
    max_R = [Ri, Ri, Ri;   
              Li, Li, Li]; 
    R = max(max_R, 2);
    Ri = R(1,1);
    Li = R(2,1);
     
    rho   = 1e-2; 
    t     = 1.001;        
    
    X = Y_init;
  % X = Observe;

Factors_dims = factor_dims(Nway, R);
rng('default')

%% G
G = cell(Ndim,1);
for n=1:Ndim
    G{n}=rand(Factors_dims(n,:));
    Gmod2{n} = my_Unfold(G{n},size(G{n}),2);
end

%% C
Core = rand(R(2,:));

%% K
K = cell(Ndim,1);
for n=1:Ndim
    K{n}=rand(Factors_dims(n,:));
    Kmod2{n} =  my_Unfold(K{n},size(K{n}),2);
end

%% F
F = cell(Ndim,1);
for n=1:Ndim
    F{n}=rand(Factors_dims(n,:));
    Fmod2{n} = my_Unfold(F{n},size(F{n}),2);
end

%% Q
Q = cell(Ndim,1);
for n=1:Ndim
    Q{n}=zeros(tsize(n)-1, Ri*Ri*Li);
end

%% A/B
A = cell(Ndim,1);
B = cell(Ndim,1);
Bt = cell(Ndim,1);
Asq = cell(Ndim,1);
for n=1:Ndim
    A{n}=randn(tsize(n),r(n));
    B{n}=randn(r(n), Ri*Ri*Li);
    Bt{n}=B{n}';
end

%% 
for n=1:Ndim
    D{n}=zeros(tsize(n)-1,tsize(n));
    for j=1:tsize(n)-1
        D{n}(j,j)=1;
        D{n}(j,j+1)=-1;
    end
end


%% Y
Y = cell(Ndim,1);
for n=1:Ndim
    Y{n}=zeros(Factors_dims(n,:));
    Ymod2{n} = my_Unfold(Y{n},size(G{n}),2);
end

%% Z
Z = cell(Ndim,1);
for n=1:Ndim
    Z{n}=zeros(Factors_dims(n,:));
    Zmod2{n} = my_Unfold(Z{n},size(Z{n}),2);
end

%% W
W = cell(Ndim,1);
for n=1:Ndim
    W{n}=zeros(tsize(n)-1, Ri*Ri*Li);
end

%% ----------------------------------------------------
%% main
for k = 1:maxit
    X_old = X;
       
     %% Update A +
      for n=1:Ndim
          A{n} = Fmod2{n}*Bt{n};
      end
    
    
     %% Update B +
      for n=1:Ndim
          Asq{n} = A{n}'*A{n};
          B{n}  = pinv(Asq{n})*A{n}'*Fmod2{n};
          Bt{n} = B{n}'; 
      end 
      
             
    %% Update K_n, n=1,2,...,N.   
    for n=1:Ndim
        Kmode2{n}= (rho*D{n}'*D{n} + rho * eye(tsize(n)))\(rho*D{n}'*Q{n} + D{n}'* W{n} + rho * Gmod2{n} - Zmod2{n});       
        K{n} = my_Fold(Kmode2{n}, size(K{n}), 2);
    end
         
    
    %% Update G_n, n=1,2,...,N.
    for n = 1:Ndim      
        GCrest = tenremat(circ_tnprod_rest(G,Core,n), Ndim);  
        TempA  = tenmat_sb(X,n)*GCrest'+rho*my_Unfold(F{n},size(F{n}),2)+my_Unfold(Y{n},size(Y{n}),2)+rho*my_Unfold(K{n},size(K{n}),2)+my_Unfold(Z{n},size(Z{n}),2);
        TempB  = (GCrest*GCrest')+2*rho*eye(size(GCrest,1),size(GCrest,1));
        G{n} = my_Fold(TempA*pinv(TempB),size(G{n}),2);
        Gmod2{n} = my_Unfold(G{n},size(G{n}),2);
    end
    
    %% Update the core tensor C
    Girest = tnreshapemat(order_tnprod_rest(G), Ndim);
    TempC = reshape(X,[1,prod(Nway)])*Girest';
    TempD = (Girest*Girest');
    TempE = TempC*pinv(TempD);
    Core = reshape(TempE,size(Core));


   %% Update F
   for n = 1:Ndim 
     tempF1 = 2*lamda*A{n}*B{n} + rho*Gmod2{n} - Ymod2{n};
     tempF2 = 2*lamda+rho;
     Fmod2{n}     = tempF1/tempF2;      
     F{n} = my_Fold(Fmod2{n},size(F{n}),2);    
   end
   
   
     %% Update Q
      for n = 1:Ndim
         Qn = Q{n};
        [Qdim,~] = size(Qn);   
        tempQ = D{n}*Kmod2{n} - W{n}/rho;
        for d = 1:Qdim
            Qhat = tempQ(d,:);
            Qn(d,:) = Qhat.*max(norm(Qhat)-mu/rho, 0)/(norm(Qhat)+eps);
        end
        Q{n} = Qn;
      end

    % Update X 
    X = reshape(TempE*Girest,Nway);
    X(Omega) = Y_init(Omega);
    
     
    % Update Y 
    for n = 1:Ndim
        Y{n} =  Y{n} + rho*(F{n} - G{n});  
        Ymod2{n} = my_Unfold(Y{n},size(G{n}),2);
    end 
    
    % Update Z 
    for n = 1:Ndim
        Z{n} =  Z{n} + rho*(K{n} - G{n});  
        Zmod2{n} = my_Unfold(Z{n},size(Z{n}),2);
    end
    
    % Update W
    for n = 1:Ndim
        W{n} =  W{n} + rho*(Q{n} - D{n}*Kmod2{n});     
    end
    
    rho = t*rho;
    
    
    %% check the convergence
    rel = norm(X(:)-X_old(:)) / norm(X_old(:));

   [mpsnr,mssim,ergas] = msqia(Omsi, X);
    msa = MSA(Omsi,X);
    fprintf('iter %d mpsnr= %f mssim= %f ergas= %f msa= %f\n',k,mpsnr,mssim,ergas,msa);
    

    if rel < tol 
        break;
    end
end



