## Description
- Matlab code for the paper: "TENSOR WHEEL COMPLETION WITH PARALLEL MATRIX FACTORIZATION AND GROUP SPARSITY SMOOTHNESS for HYPERSPECTRAL IMAGE RECOVERY".

- Copyright: Xin Tian, Kun Xie, Jigang Wen


## Get started
- Directly run: ``Demo_Pavia.m`` for an example on Pavia data.


## Contact
If interested, feel free to email me at <tianxin1307@hnu.edu.cn>.
