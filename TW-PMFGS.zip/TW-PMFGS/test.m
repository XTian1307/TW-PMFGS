

load('Pavia80.mat')
Omsi = Pavia80;


Omsi(Omsi<0) = 0;
if max(Omsi(:))>1
    Omsi = Omsi/max(Omsi(:));
end

sr = 0.2;   % sample_ratio
fprintf('### Performing SR: %4.2f ###\n', sr);

opt.tol = 1e-4;
opt.maxit = 600;

opt.lamda = 0.001;
opt.mu    = 0.25;   
opt.Ri    = 15;
opt.Li    = 5; 
opt.r     = 5;  

X = TWPMFGS(Omsi,sr,opt);

[mpsnr,mssim,ergas] = msqia(Omsi, X);
msa = MSA(Omsi,X);
fprintf('iter %d mpsnr= %f mssim= %f ergas= %f msa= %f\n',k,mpsnr,mssim,ergas,msa);






