function [G, Core] = rank_inc_adaptive(G, Core, rank_inc, N)
    % increase the estimated rank until max_R
    for j = 1:N
    G{j} = padarray(G{j}, rank_inc(j,:), rand(1), 'post');
    end
    Core = padarray(Core, rank_inc(:,3), rand(1), 'post');
end