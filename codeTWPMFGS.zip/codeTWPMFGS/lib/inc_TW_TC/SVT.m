
function [ myM ] = SVT(myM, mu,speedup) %1
    if(speedup==0)                %2
        [U,S,V]=svd(myM,'econ');  %3
    else                          %4
        [U,S,V]=FastSVD(myM,100); %5
    end                           %6
    [row,col]=size(S);            %7
    bound=min([row col]);         %8
    for i=1:bound                 %9
        if(S(i,i)>mu)             %10
            S(i,i)=S(i,i)-mu;     %11
        else                      %12
            S(i,i)=0;             %13
        end                       %14
    end                           %15
    myM=U*S*V';                   %16
end                               %17

