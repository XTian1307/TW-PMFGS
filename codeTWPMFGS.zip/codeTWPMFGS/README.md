## Description
- Matlab code for the paper: "Tensor Wheel Completion with Parallel Matrix Factorization and Group Sparsity Smoothness for Hyperspectral Image Recovery".

- Copyright: Xin Tian, Kun Xie, Jigang Wen


## Get started
- Directly run: ``test.m`` for an example on Pavia data.


## Contact
If interested, feel free to email me at <tianxin1307@hnu.edu.cn>.
